# Silver's VR180 Tool - Windows Build Instructions

This folder contains all the files needed to build the Windows version of Silver's VR180 Tool.

## Files Included
- `vr180_gui.py` - Main application code
- `vr180_processor.spec` - PyInstaller configuration
- `build_windows.bat` - Automated build script
- `requirements.txt` - Python dependencies

## Prerequisites (Install on Windows)

### 1. Python 3.8 or newer
- Download from: https://www.python.org/downloads/
- **Important**: During installation, check ✓ "Add Python to PATH"

### 2. FFmpeg
- Download from: https://www.gyan.dev/ffmpeg/builds/
- Download the "ffmpeg-release-full.7z" file
- Extract to `C:\ffmpeg`
- Add `C:\ffmpeg\bin` to your Windows PATH environment variable

**To add to PATH:**
1. Search for "Environment Variables" in Windows
2. Click "Environment Variables" button
3. Under "System variables", find and select "Path"
4. Click "Edit"
5. Click "New"
6. Add: `C:\ffmpeg\bin`
7. Click "OK" on all dialogs

## Build Steps

### 1. Transfer Files
Copy this entire `windows-build-files` folder to your Windows computer.

### 2. Open Command Prompt
- Press `Win + R`
- Type `cmd` and press Enter

### 3. Navigate to Folder
```cmd
cd path\to\windows-build-files
```

### 4. Install Python Dependencies
```cmd
pip install -r requirements.txt
```

### 5. Run Build Script
```cmd
build_windows.bat
```

The build process will:
- Verify FFmpeg is installed
- Install dependencies
- Bundle FFmpeg with the application
- Create a standalone executable

## Build Output

After successful build:
- **Location**: `dist\VR180Processor\`
- **Executable**: `dist\VR180Processor\VR180Processor.exe`
- **Size**: ~250MB (includes everything needed)

## Distribution

To share with others:
1. Compress the entire `dist\VR180Processor\` folder to a ZIP file
2. Share the ZIP file

**Users can:**
1. Download and extract the ZIP
2. Run `VR180Processor.exe` directly
3. No installation needed - fully portable!

## Troubleshooting

### "FFmpeg not found"
Make sure:
- FFmpeg is extracted to `C:\ffmpeg`
- `C:\ffmpeg\bin` is in your PATH
- Restart Command Prompt after adding to PATH

### "Python not found" or "pip not found"
- Reinstall Python and check "Add Python to PATH"
- Restart Command Prompt

### "PyInstaller not found"
Run:
```cmd
pip install -r requirements.txt
```

### Build succeeds but app doesn't run
- Make sure FFmpeg was bundled (check `dist\VR180Processor\ffmpeg.exe`)
- Try running from Command Prompt to see error messages:
  ```cmd
  dist\VR180Processor\VR180Processor.exe
  ```

## Notes

- This creates a fully standalone Windows application
- No Python or FFmpeg installation required on target computers
- The app is portable - can run from any folder or USB drive
- Windows may show "Windows protected your PC" - this is normal for unsigned apps
  - Click "More info" → "Run anyway"

## Features

✓ VR180 video processing with panomap adjustments
✓ LUT support with intensity control
✓ Real-time preview
✓ Multiple export formats (H.265, ProRes)
✓ Hardware acceleration (NVENC on NVIDIA GPUs)
✓ Progress tracking with FPS and percentage

---

**Version**: 1.0.0
**App Name**: Silver's VR180 Tool
